# CarRacing-v3 — 6-Method Experiment
## Theory: AUG+CURL+RL > CURL+RL > AUG+RL > PPO

---

## File Layout

```
common.py             ← shared infrastructure (import this in every script)
train_ppo.py          ← Method 1: Vanilla PPO
train_aug_rl.py       ← Method 2: AUG + RL
train_ssl_rl.py       ← Method 3: SSL (Autoencoder) + RL
train_aug_ssl_rl.py   ← Method 4: AUG + SSL + RL
train_curl_rl.py      ← Method 5: CURL (Contrastive) + RL
train_aug_curl_rl.py  ← Method 6: AUG + CURL + RL  ← expected BEST
aggregate_results.py  ← run after all training to build combined dashboard
```

All results are saved to: `vscoderesult_new/seed_<SEED>/` (one folder per seed)

---

## How to Run

Every script takes `--seed` (use 42, 123 and 2024 for **every** method). Default is 42.
`run_all.ps1` runs all 6 methods x 3 seeds, two jobs at a time.

Or open **6 separate terminals** and run one script per terminal (add `--seed 123`, `--seed 2024` for the other seeds):

```bash
# Terminal 1
python train_ppo.py

# Terminal 2
python train_aug_rl.py

# Terminal 3
python train_ssl_rl.py

# Terminal 4
python train_aug_ssl_rl.py

# Terminal 5
python train_curl_rl.py

# Terminal 6
python train_aug_curl_rl.py
```

Then after all 6 finish:
```bash
python aggregate_results.py
```

> **GPU tip**: If you only have one GPU, the scripts share it automatically
> since PyTorch's CUDA is multi-process safe. If VRAM is tight, run 2-3
> at a time instead of all 6 simultaneously.

---

## What Each Script Saves

Each `train_*.py` writes to `vscoderesult_new/seed_<SEED>/`:
| File | Contents |
|------|----------|
| `rewards_METHOD.json` | List of episode rewards |
| `ep_steps_METHOD.json` | List of episode step counts |
| `video_log_METHOD.json` | 5-episode evaluation log |
| `ckpt_METHOD.zip` | Trained SB3 model |
| `video_METHOD.mp4` | Annotated evaluation video |
| `training_curve_METHOD.png` | Live training plot (every 50 eps) |
| `eval_METHOD.json` | **[new]** deterministic evaluation (10 fixed-seed episodes) at 1M / 2.5M / 4M total steps and at the end |
| `run_info_METHOD.json` | **[new]** pretraining / RL / total / evaluation env steps (written when the run finished) |
| `hyperparameters.json` | **[new]** every hyper-parameter, warm-up, fine-tune LR, rollout length, pretraining details |

`aggregate_results.py` then reads all JSONs and generates:
| File | Contents |
|------|----------|
| `dashboard_carracing_6methods_v3.png` | 10-panel comparison dashboard |
| `all_methods_overlay.png` | Combined learning curves |
| `individual_plots/curve_*.png` | Per-method detailed plots |
| `raw_episode_rewards.json` | All rewards combined |
| `method_stats.json` | Summary statistics |
| `method_stats.csv` | CSV for Excel/Sheets |
| `rolling_averages.csv` | Causal rolling averages |
| `video_evaluation_log.csv` | Video eval scores |
| `results_table.tex` | LaTeX table for paper |
| `results_report.txt` | Human-readable report |
| `carracing_results_TIMESTAMP.zip` | Full ZIP bundle |

---

---

## What changed after the reviews

See `CHANGES.md` (every changed line in the code is tagged `[REVIEW-n]`, full diff in `changes.diff`).

---

## Resume after a crash / stop  [RESUME]

You can stop `run_all.ps1` (Ctrl+C, crash, power cut, closed window) at any time and simply run it again:

* **Finished runs are skipped** - each completed (seed, method) writes `done_<METHOD>.json`.
* **Unfinished runs continue** from the last auto-save instead of starting from step 0. Every 250,000 RL steps
  (`RESUME_EVERY` in `common.py`) the model, optimizer and episode logs are saved to
  `resume_<METHOD>.zip` and `resume_state_<METHOD>.json`. Pretraining (AE / CURL) is not repeated, because the pretrained encoder is stored inside the model.
* **A job that crashes is restarted automatically** by `run_all.ps1` (up to 3 attempts per batch).
* The same works for a single script: `python train_curl_rl.py --seed 123` twice in a row.
* If the stop happens during the final evaluation / video, nothing is re-trained (a final save is made right after training).

Worst case you lose up to 250k steps of training (plus pretraining if it was still running). Resumed runs are not bit-identical to
uninterrupted ones (random-number state and the episode in progress are not restored). To force a fresh start, delete the
`seed_<S>/resume_*` and `done_*` files of that method.

**Linux:** use `run_all.sh` (same logic as `run_all.ps1`): `chmod +x run_all.sh && ./run_all.sh`.
Keep it running after closing the terminal: `nohup ./run_all.sh > run_all.log 2>&1 &`. To continue after a stop, just run it again.
