# Changes made because of the reviews (nothing else was touched)

Every changed line in the code carries a `# [REVIEW-n]` tag. Full line-by-line diff: `changes.diff`.
Files changed: `common.py`, the six `train_*.py`, `aggregate_results.py`, `run_all.ps1`, `README.md`.
NOT added: no runner, no new checkpoint system, no refactor. Your own resume code in `train_curl_rl.py` is unchanged.

## [REVIEW-1] Unequal training budgets  (R1, R2, R3, R4)
| before | now |
|---|---|
| RL steps 2.5M / 3.5M / 4M / 4M / 5.5M / 6.5M | one `COMMON_STEPS = 6_500_000` for all six methods (R4's suggestion: PPO also trained for 6.5M) |
| pretraining frames (80k) not counted | RL steps = `COMMON_STEPS - pretraining frames`, so total environment experience is equal |
| warm-up 1.8M / 1.8M / 2.5M / 3.0M | same fraction (`WARMUP_FRACTION = 0.46`) of the RL budget for all SSL methods |
| fine-tune LR 5e-6, except AUG+CURL+RL 1e-6 | 5e-6 for all (needed so CURL+RL vs AUG+CURL+RL differ only in augmentation) |

`COMMON_STEPS` is one line in `common.py`. 18 runs x 6.5M is a lot of compute; if you lower it, warm-up scales automatically.
PPO rounds up to whole rollouts, so totals can differ by one rollout (8,192 or 24,576 steps, < 0.4 %); exact values are in `run_info_*.json`.

## [REVIEW-2] Different number of seeds  (R2)
`python train_xxx.py --seed 42|123|2024` (default 42). Results go to `vscoderesult_new/seed_<S>/`, so seeds cannot overwrite each other. `run_all.ps1` runs all 6 methods x 3 seeds, two at a time. The random-policy pretraining data is now also seeded.

## [REVIEW-3] Training reward vs evaluation; matched steps  (R3)
`common.py` section 13: `EvalCB` + `final_evaluate`. Separate clean env (no augmentation), deterministic actions, 10 fixed-seed episodes (same seeds for every method), no model update, training RNG restored afterwards. Done at 1M / 2.5M / 4M **total** steps (pretraining frames included) and at the end. Saved to `eval_<method>.json` (all episode returns, mean, std). Evaluation steps are counted separately (`run_info_*.json`), never in the budget.
`aggregate_results.py` now shows, per method: n seeds, mean ± std across seeds of the final evaluation, and the same at each matched step. A seed is used only if its final evaluation exists (unfinished seeds are listed, not averaged). No significance test is claimed.

## [REVIEW-4] Augmentation applied inconsistently; CURL vs AUG+CURL unclear  (R3)
One rule for the AUG factor: **random shift (+-4 px, `aug_heavy`) on the RL observations only.**
| method | pretraining | RL observations |
|---|---|---|
| PPO | - | clean |
| AUG+RL | - | AUG |
| AUTO+RL | clean frames, noise 0.05, 350 updates | clean |
| AUTO+RL+AUG | **identical to AUTO+RL** (was: shifted frames, noise 0.08, 400) | AUG |
| CURL+RL | CURL views (its own shift+brightness 0.025), 800 updates | **clean** (was: CURL views also in RL) |
| AUG+CURL+RL | **identical to CURL+RL** (was: heavy views 0.05, 1000 updates) | AUG (same op as AUG+RL) |

So each pair now differs in exactly one thing. Verified by diffing the scripts.

## [REVIEW-5] Missing details  (R3)
`hyperparameters.json` is written into every seed folder: warm-up, fine-tune LR, rollout length, minibatch, PPO epochs, entropy coef, encoder architecture, pretraining policy (uniform random), and that one pretraining "epoch" = one mini-batch update.
Values were not changed, only reported. Note for the paper: PPO/AUG+RL use `PPO_KW_CNN`, the four SSL methods use `PPO_KW_MLP` (different lr, rollout, epochs, clip, coefficients).

## Paper-side only (no code change)
R4: tone down "autonomous driving / self-driving" claims (top-down CarRacing); soften "representation beats augmentation" (static, DrQ-shift only); frame Section 5 by task type. R3: "identical settings" wording, best-episode bolding, no code release mentioned, narrow novelty. R2: more recent visual-RL baselines. R4: DMC-VB suggestion. **Cheetah-Run is not in the code you sent**, so its runs cannot be re-run from this code.

## Tests actually run
Modified scripts executed with tiny budgets on CPU (1,600 steps, 40-step episodes, 256 pretraining frames), seed 42 for all 6 methods and seed 123 for 3 of them: all finished; per-seed folders; equal totals; `eval_*`/`run_info_*`/`hyperparameters.json` written; aggregation across seeds and matched steps worked; an unfinished seed was excluded; your `train_curl_rl.py` resume path still works. **Not run:** the real budget, GPU, Windows/PowerShell (`run_all.ps1`).

## Found but NOT changed (you asked for no extra changes) - please read
Checked against stable-baselines3 2.9.0; they may affect result validity (R3: "results not properly validated"):
1. `SSLExtractorCNN.forward` reshapes the observation as `(B,64,64,12)`, but SB3 delivers it channel-first `(B,12,64,64)`. The pretrained encoder therefore sees scrambled pixels during RL in all four AUTO/CURL methods.
2. `UnfreezeEncoderCB` sets the optimizer LR, but SB3 resets it at the start of every update, so `FINETUNE_LR` never takes effect.
3. `aug_random_shift(_batch)` has no scale term, so besides shifting it zooms the image to 64/72 even at zero shift (train/eval mismatch for AUG methods).
Say the word and I will give you these as three tiny separate patches.

## [RESUME] Crash-safe training (added later)
`common.py` section 14 (`train_resumable`, `AutoSaveCB`, `skip_if_complete`, `mark_complete`); all six `train_*.py` call it; `run_all.ps1` skips finished jobs and retries crashed ones. See README "Resume after a crash". The old resume block in `train_curl_rl.py` was replaced by this (it looked for `ckpt_CURL+RL.zip`, which was only written at the very end, so it could never resume a run that was cut off).
Tested: resume logic against a stand-in PPO (crash at 7,500 -> resumed from 6,000 -> finished, pretraining ran once, done-flag + skip worked). **Not tested** with real stable-baselines3/CarRacing (no space to install in my sandbox) and not in PowerShell - please run one short test first (set `COMMON_STEPS` small, Ctrl+C in the middle, run again).
