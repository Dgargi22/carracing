import marimo

__generated_with = "0.25.1"
app = marimo.App(width="medium")


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # CarRacing Experiment Analysis

    This notebook is used to run and analyze the CarRacing experiments.
    """)
    return


@app.cell
def _(mo):
    run_button = mo.ui.run_button(label="Run All CarRacing Experiments")
    run_button
    return (run_button,)


@app.cell
def _(mo, run_button):
    import subprocess
    from pathlib import Path

    def _already_running():
        cmd = ("Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and "
               "$_.CommandLine -match 'run_all\\.ps1|train_\\w+\\.py' } | "
               "Select-Object -ExpandProperty ProcessId")
        out = subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                             capture_output=True, text=True).stdout.split()
        return out

    mo.stop(not run_button.value)

    _folder = Path("run_all.ps1").resolve().parent
    _running = _already_running()
    if _running:
        print("Already running (PIDs:", ", ".join(_running), ") - not starting a second copy.")
    else:
        subprocess.Popen(
            ["powershell", "-NoExit", "-ExecutionPolicy", "Bypass", "-File", "run_all.ps1"],
            cwd=_folder,
            creationflags=subprocess.CREATE_NEW_CONSOLE,   # opens its own visible window
        )
        print("Started in a new PowerShell window. Keep that window open.")
    return


@app.cell
def _(mo):
    refresh = mo.ui.refresh(options=["30s", "1m", "5m"], default_interval="1m")
    refresh
    return (refresh,)


@app.cell
def _(mo, refresh):
    _ = refresh.value
    import pathlib

    _base = pathlib.Path("vscoderesult_new")
    _logs = sorted(_base.glob("seed_*/log_*.txt"), key=lambda p: p.stat().st_mtime, reverse=True)
    _done = sorted(p.parent.name + "/" + p.name for p in _base.glob("seed_*/done_*.json"))
    _pngs = sorted(_base.glob("seed_*/training_curve_*.png"), key=lambda p: p.stat().st_mtime, reverse=True)

    _text = "Finished: " + (", ".join(_done) if _done else "none yet") + "\n\n"
    for _l in _logs[:2]:
        _text += f"--- {_l} ---\n" + "".join(_l.read_text(encoding="utf-8", errors="replace").splitlines(True)[-8:]) + "\n"
    if not _logs:
        _text += "No log files yet - training has not started or crashed. Check the PowerShell window."

    mo.vstack([mo.md(f"```\n{_text}\n```"), mo.image(src=str(_pngs[0])) if _pngs else mo.md("_No training curve yet (first one appears after 50 episodes)_")])
    return


if __name__ == "__main__":
    app.run()
